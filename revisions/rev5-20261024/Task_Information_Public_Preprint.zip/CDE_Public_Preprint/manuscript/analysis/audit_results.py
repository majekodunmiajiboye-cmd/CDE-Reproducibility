"""Recompute reported contrasts from included outcome and benchmark summaries.

No candidate-model inference is performed. Benchmark bootstrap conditions on
saved predictions and does not estimate full fitting uncertainty. The aggregate
records suffice for the reported paired benchmark bootstrap because all targets
have the same complete item set. Raw model text and item-level predictions are
separate source artifacts, not represented by this numerical audit dataset.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import binomtest

ROOT = Path(__file__).resolve().parents[1]
SPECS = ['RD','RT18','RT18D','RTFULL','RTFULLD']


def load_benchmarks() -> pd.DataFrame:
    rows = []
    setting = None
    for line in (ROOT/'data/benchmark_gains.txt').read_text().splitlines():
        if line.startswith('SETTING '):
            setting = line.split()[1]
            continue
        x = line.split('|')
        if len(x) != 7 or setting is None:
            raise ValueError(f'Malformed benchmark row: {line}')
        row = dict(setting=setting, benchmark=x[0], n_items=int(x[1]))
        row.update(dict(zip(SPECS,map(float,x[2:]))))
        rows.append(row)
    d = pd.DataFrame(rows)
    assert len(d)==60
    assert all(d.groupby('setting').n_items.sum()==16108)
    return d


def paired_p(gain: int, loss: int) -> float:
    return 1.0 if gain+loss==0 else float(binomtest(gain,gain+loss,.5).pvalue)


def main() -> None:
    d = load_benchmarks()
    d.to_csv(ROOT/'data/benchmark_gains.csv',index=False)
    result = dict(prediction={}, direct_prediction={}, programming={})
    for setting, g in d.groupby('setting',sort=False):
        g=g.sort_values('benchmark')
        n=g.n_items.to_numpy(dtype=float)
        rng=np.random.default_rng(20260926)
        out={}
        for s in SPECS:
            v=g[s].to_numpy()
            ix=rng.integers(0,len(g),(10000,len(g)))
            boot=(v[ix]*n[ix]).sum(axis=1)/n[ix].sum(axis=1)
            out[s]=dict(delta=float(np.average(v,weights=n)),
                equal_benchmark=float(v.mean()),
                ci95=np.quantile(boot,[.025,.975]).tolist(),
                positive=int((v>0).sum()),negative=int((v<0).sum()))
        result['prediction'][setting]=out
        direct={}
        for left,right in [('RT18','RD'),('RT18','RT18D'),('RD','RT18D'),('RTFULL','RD')]:
            # Stored values are L(R)-L(spec), hence reverse subtraction.
            v=(g[right]-g[left]).to_numpy()
            rng=np.random.default_rng(20260927)
            ix=rng.integers(0,len(g),(10000,len(g)))
            boot=(v[ix]*n[ix]).sum(1)/n[ix].sum(1)
            direct[f'{left}_minus_{right}']=dict(delta=float(np.average(v,weights=n)),
                 ci95=np.quantile(boot,[.025,.975]).tolist())
        result['direct_prediction'][setting]=direct

    # Post-hoc extended-grid sensitivity on the same LOBO folds.
    ext=json.loads((ROOT/'data/extended_c_summary.json').read_text())
    eb=pd.read_csv(ROOT/'data/extended_c_benchmark_gains.csv').sort_values('benchmark')
    assert len(eb)==20 and int(eb.n_items.sum())==16108
    n=eb.n_items.to_numpy(float)
    rng=np.random.default_rng(20260926)
    extcalc={}
    for spec in SPECS:
        v=eb[spec].to_numpy(float)
        ix=rng.integers(0,len(eb),(10000,len(eb)))
        boot=(v[ix]*n[ix]).sum(1)/n[ix].sum(1)
        extcalc[spec]=dict(delta=float(np.average(v,weights=n)), equal_benchmark=float(v.mean()),
            ci95=np.quantile(boot,[.025,.975]).tolist(), positive=int((v>0).sum()), negative=int((v<0).sum()))
    assert abs(extcalc['RTFULL']['delta']-ext['RTFULL_vs_R']['delta_ll_R_minus_spec'])<1e-12
    assert abs(extcalc['RTFULL']['ci95'][0]-ext['RTFULL_vs_R']['benchmark_cluster_ci95'][0])<1e-12
    assert abs(extcalc['RTFULL']['ci95'][1]-ext['RTFULL_vs_R']['benchmark_cluster_ci95'][1])<1e-12
    assert extcalc['RTFULL']['positive']==3 and extcalc['RTFULL']['negative']==17
    assert ext['selected_c_counts']['RTFULL']['0.0001']==0
    assert ext['selected_c_counts']['RTFULL']['0.001']==104
    assert ext['selected_c_counts']['RTFULL']['0.01']==196
    result['extended_c_sensitivity']=dict(summary=ext, benchmark_recalculation=extcalc)

    p=pd.read_csv(ROOT/'data/programming_outcomes.csv')
    assert len(p)==576 and not p.duplicated(['task','model','arm']).any()
    assert p.task.nunique()==72
    assert ((p['pass']<=p['compile']) & (p['compile']<=p.accepted)).all()
    assert (p.accepted==(p.original_extraction | p.tolerant_wrapped)).all()
    p['strict_pass']=p['pass']*p.original_extraction
    contrasts=[('NL','NL+scaffold'),('NL+scaffold','BOTH'),('NL+scaffold','SPEC'),('NL','SPEC'),('NL','BOTH')]
    for model,g in p.groupby('model'):
        grid=g.pivot(index='task',columns='arm',values='pass')
        tests={}
        for a,b in contrasts:
            diff=(grid[b]-grid[a]).to_numpy()
            gain=int((diff>0).sum()); loss=int((diff<0).sum())
            tests[b+' minus '+a]=dict(effect_pp=float(diff.mean()*100),gain=gain,loss=loss,p=paired_p(gain,loss))
        result['programming'][model]=dict(
            counts=g.groupby('arm')[['original_extraction','tolerant_wrapped','compile','pass','strict_pass','runtime_timeout','generation_length_limit']].sum().to_dict('index'),
            contrasts=tests)
    interaction_grid=p.pivot(index='task',columns=['model','arm'],values='pass')
    between={}
    for control,treatment in contrasts:
        x=((interaction_grid['Gemma'][treatment]-interaction_grid['Gemma'][control])-
           (interaction_grid['Devstral'][treatment]-interaction_grid['Devstral'][control])).to_numpy()
        positive=int((x>0).sum()); negative=int((x<0).sum())
        between[treatment+' minus '+control]=dict(mean_difference_pp=float(x.mean()*100),
            positive=positive,negative=negative,zero=int((x==0).sum()),sign_p=paired_p(positive,negative))
    result['between_model_direction_tests']=between
    gem=p[p.model=='Gemma']
    grid=gem.pivot(index='task',columns='arm')
    strict=(grid.strict_pass.SPEC-grid.strict_pass.NL).mean()
    tolerant=(grid['pass'].SPEC-grid['pass'].NL).mean()
    result['score_accounting']=dict(strict_gap_pp=strict*100,tolerant_gap_pp=tolerant*100,
        difference_pp=(strict-tolerant)*100,observed_gap_fraction_removed=(strict-tolerant)/strict)
    assert abs(strict-.25)<1e-12 and abs(tolerant-2/72)<1e-12
    assert abs(result['prediction']['lobo_fixed']['RD']['delta']-.006276607667505058)<1e-12
    assert abs(result['prediction']['lobo_nested']['RD']['delta']-.006254629138219636)<1e-12
    assert abs(result['programming']['Gemma']['contrasts']['BOTH minus NL+scaffold']['p']-.0654296875)<1e-12
    assert abs(result['between_model_direction_tests']['SPEC minus NL']['sign_p']-.31050465907901525)<1e-12
    for outcome in ['strict_pass','pass']:
        x=(grid[outcome].SPEC-grid[outcome].NL).to_numpy()
        result['score_accounting'][outcome+'_exact_p']=paired_p(int((x>0).sum()),int((x<0).sum()))
    source_rows=[]
    for (model,source),g in p.groupby(['model','source']):
        grid=g.pivot(index='task',columns='arm',values='pass')
        x=grid.BOTH-grid['NL+scaffold']
        source_rows.append(dict(model=model,source=source,n=len(x),gain=int((x>0).sum()),loss=int((x<0).sum()),effect_pp=float(x.mean()*100)))
    result['exploratory_source_split']=source_rows
    (ROOT/'data/audit_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    print('PASS: pairing, cell counts, score decomposition, primary tests, and predictive contrasts.')

if __name__=='__main__':
    main()
