from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
a=json.loads((ROOT/'data/audit_result.json').read_text())
b=pd.read_csv(ROOT/'data/benchmark_gains.csv')
p=pd.read_csv(ROOT/'data/programming_outcomes.csv')
labels={'R':'$R$','RD':'$R+D$','RT18':'$R+T_{18}$','RT18D':'$R+T_{18}+D$','RTFULL':'$R+T_{768}$','RTFULLD':'$R+T_{768}+D$'}
settings={'lotf_fixed':'Task-family, fixed $C$','lobo_fixed':'Benchmark, fixed $C$','lobo_nested':'Benchmark, nested $C$'}
metrics={
'lotf_fixed':{
'log_loss':[.3566549035432885,.3504541718135979,.3514418180976434,.34984894832478464,.39325381412823696,.3927087064190185],
'brier':[.11254247442339232,.11038474358828039,.11079958398752114,.11024062596711817,.12322585398817643,.12291829663915159],
'accuracy':[.8414452445989571,.8445079049747537,.8431710951080209,.8444334078304776,.8264299312970781,.8269265789255856]},
'lobo_fixed':{
'log_loss':[.3740224889199219,.36774588125241675,.3720271426511416,.3696341030799044,.455640801364326,.45750845921423955],
'brier':[.11783597508405563,.11614747510578645,.11726443657039201,.11676693524720873,.13946971549109324,.13982684153937702],
'accuracy':[.8341776343017963,.8356882708385067,.8342686863670226,.834227299064647,.8068661534641172,.8061129045608807]},
'lobo_nested':{
'log_loss':[.37252562102957854,.3662709918913588,.3683140929417579,.36659899346096075,.38647120227513226,.38717268986698694],
'brier':[.11727701392076759,.11552632989766817,.11603766262970323,.11574415816493663,.12256408732031678,.12315584974670701],
'accuracy':[.8346742819303038,.8369795546726264,.8360731727506001,.8352868140054631,.8257511795381177,.8243398725271087]}}
(ROOT/'data/predictive_metrics.json').write_text(json.dumps({'spec_order':list(labels),'settings':metrics},indent=2)+'\n')
def table(name,caption,cols,head,rows,note=''):
 rows=[r+chr(92) if r.endswith(chr(92)) and not r.endswith(chr(92)*2) else r for r in rows]
 text='\\begin{table}[tbh]\n\\caption{'+caption+'}\n\\centering\\small\n\\begin{tabular}{'+cols+'}\n\\toprule\n'+head+' \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n'
 if note: text+='\\par\\smallskip\\raggedright\\footnotesize '+note+'\n'
 text+='\\end{table}\n'
 (ROOT/'tables'/f'{name}.tex').write_text(text)
rows=[]
for st in settings:
 for j,s in enumerate(labels):
  v=metrics[st]
  rows.append(f"{settings[st] if j==0 else ''} & {labels[s]} & {v['log_loss'][j]:.5f} & {v['brier'][j]:.5f} & {100*v['accuracy'][j]:.2f} \\")
 rows.append('\\midrule')
rows=rows[:-1]
table('all_metrics','All predictive metrics. Accuracy uses threshold 0.5 and is supplemental. All columns describe the external predictor, not a change in candidate-model success.','llrrr','Setting & Predictor & Log loss & Brier & Accuracy (\\%)',rows)
rows=[]
for st in settings:
 for j,s in enumerate(list(labels)[1:]):
  z=a['prediction'][st][s]
  rows.append(f"{settings[st] if j==0 else ''} & {labels[s]} & {z['delta']:+.5f} & [{z['ci95'][0]:+.5f}, {z['ci95'][1]:+.5f}] & {z['equal_benchmark']:+.5f} & {z['positive']}/20 \\")
 rows.append('\\midrule')
table('all_gains','Paired gains over $R$. Positive differences favour the augmented predictor. Intervals are 10,000-draw benchmark-cluster percentiles conditional on saved predictions.','llrrrc','Setting & Predictor & Gain & 95\\% interval & Equal-benchmark & Positive',rows[:-1])
for st in settings:
 rows=[]
 for _,r in b[b.setting==st].iterrows():
  bench=r.benchmark.replace('&',r'\&')
  vals=' & '.join(f'{r[s]:+.4f}' for s in list(labels)[1:])
  rows.append(f'{bench} & {int(r.n_items)} & {vals} \\\\')
 table('bench_'+st,settings[st]+'. Per-benchmark gains over $R$, averaged over the fifteen targets. No benchmark is omitted.','lrrrrrr','Benchmark & Items & $D$ & $T_{18}$ & $T_{18}+D$ & $T_{768}$ & $T_{768}+D$',rows)
rows=[]
for st in ['lobo_fixed','lobo_nested']:
 for j,(k,v) in enumerate(a['direct_prediction'][st].items()):
  left,right=k.split('_minus_')
  rows.append(f"{settings[st] if j==0 else ''} & {labels[left]} minus {labels[right]} & {v['delta']:+.5f} & [{v['ci95'][0]:+.5f}, {v['ci95'][1]:+.5f}] \\")
 rows.append('\\midrule')
table('direct','Direct loss contrasts, calculated after the transfer outputs were available. A positive value favours the right-hand predictor. These intervals are unadjusted for multiple comparisons.','llrr','Setting & Left minus right & Difference & 95\\% interval',rows[:-1])
cs={'R':[39,167,35,59],'RD':[50,160,40,50],'RT18':[79,196,18,7],'RT18D':[100,160,31,9],'RTFULL':[300,0,0,0],'RTFULLD':[300,0,0,0]}
(ROOT/'data/selected_C_counts.json').write_text(json.dumps(cs,indent=2)+'\n')
table('c_counts','Selected regularisation across 300 target-by-benchmark fits per representation. Smaller $C$ means stronger penalisation.','lrrrr','Predictor & $C=0.01$ & $C=0.1$ & $C=1$ & $C=10$', [labels[k]+' & '+' & '.join(map(str,v))+r' \\' for k,v in cs.items()])
ext=json.loads((ROOT/'data/extended_c_summary.json').read_text())
ext_cs=ext['selected_c_counts']
(ROOT/'data/selected_C_counts_extended.json').write_text(json.dumps(ext_cs,indent=2)+'\n')
rows=[]
for k in labels:
 v=ext_cs[k]
 rows.append(labels[k]+' & '+' & '.join(str(v[x]) for x in ['0.0001','0.001','0.01','0.1','1','10'])+r' \\')
table('c_counts_extended','Post-hoc extended-grid sensitivity. Selected regularisation across 300 target-by-benchmark fits per representation. Smaller $C$ means stronger penalisation.','lrrrrrr','Predictor & $C=0.0001$ & $C=0.001$ & $C=0.01$ & $C=0.1$ & $C=1$ & $C=10$',rows)
rows=[]
for m in ['Devstral','Gemma']:
 for j,(name,v) in enumerate(a['programming'][m]['contrasts'].items()):
  status='Primary' if j<2 else 'Secondary'
  rows.append(f"{m} & {name} & {status} & {v['effect_pp']:+.1f} & {v['gain']}/{v['loss']} & {v['p']:.4f} \\")
 rows.append('\\midrule')
table('all_programming','All prespecified within-model semantic-test contrasts. Secondary values are unadjusted. Primary decisions use $\\alpha=0.025$ within each model.','lllrrr','Model & Treatment minus control & Status & Effect (pp) & Gains/losses & Exact $p$',rows[:-1])
rows=[]
for (m,arm),g in p.groupby(['model','arm'],sort=False):
 rows.append(f"{m} & {arm} & {int(g.original_extraction.sum())} & {int(g.tolerant_wrapped.sum())} & {int(g['compile'].sum())} & {int(g['pass'].sum())} & {int(g.runtime_timeout.sum())} & {int(g.generation_length_limit.sum())} \\")
table('diagnostics','Execution diagnostics for all 576 confirmation cells. Each row has 72 attempts. Timeout means program execution exceeded the applicable time limit. Length means generation reached its 4,096-token limit.','llrrrrrr','Model & Input & Wrapper & Wrapped & Compiles & Passes & Timeout & Length',rows)
rows=[]
for v in a['exploratory_source_split']:
 rows.append(f"{v['model']} & {v['source']} & {v['n']} & {v['gain']}/{v['loss']} & {v['effect_pp']:+.1f} \\")
table('source_split','Exploratory BOTH-minus-NL+scaffold contrasts by task source. These groups were examined after the confirmation results and are not independent confirmation of heterogeneity.','llrrr','Model & Source & Tasks & Gains/losses & Effect (pp)',rows)
print('Tables created')
