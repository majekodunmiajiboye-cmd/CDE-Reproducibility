#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 analysis/audit_results.py > data/audit_run.txt
python3 analysis/make_tables.py
if command -v tectonic >/dev/null 2>&1; then
  tectonic --keep-logs main.tex
  tectonic --keep-logs supplement.tex
else
  for name in main supplement; do
    pdflatex -interaction=nonstopmode -halt-on-error "$name.tex"
    bibtex "$name"
    pdflatex -interaction=nonstopmode -halt-on-error "$name.tex"
    pdflatex -interaction=nonstopmode -halt-on-error "$name.tex"
  done
fi
