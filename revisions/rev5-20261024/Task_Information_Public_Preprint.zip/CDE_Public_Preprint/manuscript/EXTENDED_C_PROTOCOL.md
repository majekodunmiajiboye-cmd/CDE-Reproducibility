# Study 1 post-hoc extended-C sensitivity

Status: post-hoc sensitivity motivated by the observed regularisation boundary in the completed four-value nested-C analysis.

The original fixed-C LOBO analysis and the original nested-C sensitivity remain unchanged. This run does not replace or alter their evidential status.

## Question

The completed nested-C analysis allowed C in [0.01, 0.1, 1, 10]. Every one of the 300 R+Tfull fits selected C=0.01, the strongest available penalty. This run asks whether the full 768-dimensional text comparator remains worse when stronger regularisation is available.

## Frozen implementation for this run

- Outer validation: the same 20 leave-one-benchmark-out folds.
- Target models: the same 15 ADeLe response vectors.
- Representations: R, R+D, R+T18p, R+T18p+D, R+Tfull, R+Tfull+D.
- C grid: [0.0001, 0.001, 0.01, 0.1, 1, 10].
- Every representation receives the same expanded grid.
- C selection: the same deterministic 3-fold GroupKFold on benchmark identity inside each outer-training set.
- C is selected separately for each outer fold, target model, and representation by pooled inner binary log loss.
- All scaling, benchmark encoding, PCA, and full-embedding scaling are refit inside each inner split.
- The outer held-out benchmark is untouched by hyperparameter selection.
- Primary metric for this sensitivity: benchmark-held-out binary log loss.
- Report Brier score, benchmark sign counts, equal-benchmark mean differences, and the same 10,000-draw benchmark-cluster resampling intervals.
- No representations, interaction terms, or outcome-dependent thresholds are added.

## Boundary handling

If the new smallest value C=0.0001 is again frequently selected, this run will be reported as still boundary-limited. No further grid extension is automatically triggered by the outer-test result. Any later extension would be justified, if at all, from the inner-validation behaviour and labelled separately.

## Interpretation

This is a fairness check on the high-dimensional text comparator. It cannot convert the previously specified fixed-C primary comparison into a prospective success. It may show that the earlier full-text deficit persists, disappears, or reverses under a wider post-hoc tuning grid.
