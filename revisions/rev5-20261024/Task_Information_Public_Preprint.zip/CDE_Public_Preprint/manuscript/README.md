# Named public preprint

Revision date: 24 October 2026. Preserves the Rev4 numerical results and analysis status.

Files: main.tex/main.pdf, supplement.tex/supplement.pdf, 19-entry references.bib, analysis/audit_results.py, analysis/make_tables.py, data/, REPRODUCTION_MANIFEST.json.

Run the included small audit with `python3 analysis/audit_results.py`; regenerate tables with `python3 analysis/make_tables.py`. Install analysis/requirements-audit.txt if required. This audit uses retained outcomes, not model inference.

Build with `sh build.sh` (Tectonic or pdfLaTeX/BibTeX). The public version uses the preprint template setting and names Majekodunmi Ajiboye. Author-year references are retained.

The accompanying retained_analysis directory adds 576 response-only records, a portable wrapper verifier/rerunner, original developmental audit and portable refitting adapter. See retained_analysis/evidence/README.txt. Upstream prompts, tests, model weights and embedding cache are excluded. The public preprint ZIP contains both directories together; no separately located missing-evidence ZIP is required.

Changes: exact conditional McNemar support added; Nomic/Bates entries updated to published versions; Macedo 2025 extension acknowledged; reproduction description updated. All numerical tables and scientific conclusions are unchanged.
