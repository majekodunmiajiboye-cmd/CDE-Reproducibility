# Portable programming-only adapter of development/post_review/audit_existing.py.
# ADeLe-only block omitted; programming arithmetic/fitting unchanged.
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

ap=argparse.ArgumentParser()
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True)
a=ap.parse_args(); root=a.repo
NBOOT=10000; SEED=20260927

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def loss(y,p):
    p=np.clip(np.asarray(p,dtype=float),1e-6,1-1e-6)
    return -(y*np.log(p)+(1-y)*np.log1p(-p))
def cluster_summary(frame,diffs,col,n=10000,seed=SEED):
    keys=sorted(frame[col].astype(str).unique())
    codes=pd.Categorical(frame[col].astype(str),categories=keys).codes
    sums=np.vstack([np.bincount(codes,weights=diffs[:,j],minlength=len(keys)) for j in range(diffs.shape[1])]).T
    counts=np.bincount(codes,minlength=len(keys)).astype(float)
    rng=np.random.default_rng(seed); ix=rng.integers(0,len(keys),(n,len(keys)))
    pooled=sums[ix].sum(axis=1)/counts[ix].sum(axis=1)[:,None]
    equal=(sums/counts[:,None]).mean(axis=0)
    leave=(sums.sum(axis=0)-sums)/(counts.sum()-counts)[:,None]
    return {'n_clusters':len(keys),'percentile95':np.quantile(pooled,[.025,.975],axis=0).T.tolist(),
            'equal_cluster_mean':equal.tolist(),'leave_one_cluster_out_min':leave.min(axis=0).tolist(),
            'leave_one_cluster_out_max':leave.max(axis=0).tolist()}

out={'status':'Post-review exploratory audit, not a replacement for frozen analyses. No candidate-model runs or public-repository changes.',
     'bootstrap_replicates':NBOOT,'audit_seed':SEED,
     'interval_scope':'Percentile resampling of fixed existing OOF losses or observed task blocks. These intervals do not quantify full pipeline-refitting uncertainty or establish nominal population coverage.'}
spec=importlib.util.spec_from_file_location('r4audit',root/'programming/analysis/r4b_analyze_pilot.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
pr=json.loads((root/'evidence/development/results/r4b/full_pilot/pilot_result.json').read_text())
features=json.loads((root/'programming/manifests/r4b_task_features.json').read_text())
fidx={r['problem']:r for r in features['rows'] if r['split']=='pilot'}
model_a='devstral-small-2:24b-instruct-2512-q4_K_M';model_b='gemma3:12b'
rows=[]
for r in pr['results']:
    assert r['model'] in [model_a,model_b]
    rows.append({'model':r['model'],'problem':r['problem'],'family':r['family'],'arm':r['arm'],
        'y':int(bool(r['eval']['semantic_pass'])),'model_is_a':int(r['model']==model_a),
        'arm_spec':int(r['arm']=='spec'),'arm_both':int(r['arm']=='both'),'family_cf':int(r['family']=='codeforces'),
        **{d:fidx[r['problem']][d] for d in m.D_FEATURES}})
f=pd.DataFrame(rows)
assert len(f)==144 and not f.duplicated(['model','problem','arm']).any()
assert f.groupby('problem').size().eq(6).all()
wide=f.pivot(index='problem',columns=['model','arm'],values='y').sort_index()
A={k:wide[(model_a,k)].to_numpy(float) for k in ['nl','spec','both']}
B={k:wide[(model_b,k)].to_numpy(float) for k in ['nl','spec','both']}
contrasts={'devstral_spec_minus_nl':A['spec']-A['nl'], 'gemma_spec_minus_nl':B['spec']-B['nl'],
'devstral_both_minus_nl':A['both']-A['nl'], 'gemma_both_minus_nl':B['both']-B['nl'],
'did_both_minus_nl_gemma_minus_devstral':(B['both']-B['nl'])-(A['both']-A['nl']),
'did_spec_minus_nl_gemma_minus_devstral':(B['spec']-B['nl'])-(A['spec']-A['nl']),
'devstral_both_minus_spec':A['both']-A['spec'], 'gemma_both_minus_spec':B['both']-B['spec']}
rng=np.random.default_rng(SEED);ix=rng.integers(0,24,(NBOOT,24))
cs={k:{'point_pp':float(v.mean()*100),'paired_percentile95_pp':(np.quantile(v[ix].mean(axis=1),[.025,.975])*100).tolist(),
        'positive_task_differences':int((v>0).sum()),'negative_task_differences':int((v<0).sum())} for k,v in contrasts.items()}
ps={k:m.loto_predictions(f,k) for k in ['b1','profile','cde']}
lls={k:float(loss(f.y.to_numpy(float),v).mean()) for k,v in ps.items()}
# Diagnose duplicated columns without modifying the frozen model code.
tr=np.flatnonzero(f.problem.to_numpy()!=sorted(f.problem.unique())[0]);te=np.flatnonzero(f.problem.to_numpy()==sorted(f.problem.unique())[0])
mats={k:m.build_matrix(f,tr,te,k)[0] for k in ps}
matinfo={}
for k,x in mats.items():
    duplicates=[[i,j] for i in range(x.shape[1]) for j in range(i+1,x.shape[1]) if np.array_equal(x[:,i],x[:,j])]
    matinfo[k]={'columns_excluding_intercept':x.shape[1],'rank_with_intercept':int(np.linalg.matrix_rank(np.c_[np.ones(len(x)),x])), 'exact_duplicate_columns_zero_based':duplicates}
# Prespecified for this audit: only remove the duplicated d0 column at index 7.
# This is a post-review coding sensitivity, not a revised confirmatory result.
repaired={}
for k in ['profile','cde']:
    pp=np.empty(len(f))
    for task in sorted(f.problem.unique()):
        tri=np.flatnonzero(f.problem.to_numpy()!=task);tei=np.flatnonzero(f.problem.to_numpy()==task)
        xtr,xte=m.build_matrix(f,tri,tei,k)
        assert np.array_equal(xtr[:,6],xtr[:,7])
        xtr=np.delete(xtr,7,axis=1);xte=np.delete(xte,7,axis=1)
        clf=LogisticRegression(C=1.,penalty='l2',solver='liblinear',max_iter=4000,random_state=m.SEED)
        clf.fit(xtr,f.iloc[tri].y.to_numpy(int));pp[tei]=clf.predict_proba(xte)[:,list(clf.classes_).index(1)]
    repaired[k]=float(loss(f.y.to_numpy(float),pp).mean())
fpairs=[('profile','cde'),('b1','cde')]
fdiff=np.column_stack([loss(f.y.to_numpy(float),ps[l])-loss(f.y.to_numpy(float),ps[r]) for l,r in fpairs])
out['r4b']={'counts':{name:{arm:int((A if name=='Devstral' else B)[arm].sum()) for arm in ['nl','spec','both']} for name in ['Devstral','Gemma']},
'paired_contrasts':cs,'frozen_loto_log_losses_recomputed':lls,'design_matrix_check':matinfo,
'deduplicated_column_postreview_sensitivity_log_losses':repaired,
'deduplicated_gate_loto_part_pass':repaired['cde']<repaired['profile'],
'loss_comparison_order':[l+'_minus_'+r for l,r in fpairs],
'loss_intervals':cluster_summary(f,fdiff,'problem')}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
