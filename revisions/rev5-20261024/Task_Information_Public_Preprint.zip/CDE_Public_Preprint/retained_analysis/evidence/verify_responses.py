"""Verify exported response extraction; optionally execute the 36 wrapped Gemma NL programs.
Generated programs are untrusted: execute only in an appropriate sandbox.
"""
import argparse,hashlib,json,re,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'programming/analysis'))
import r4b_local_pilot as base
p=argparse.ArgumentParser();p.add_argument('--benchmark',type=Path);p.add_argument('--tests',type=Path);p.add_argument('--execute',action='store_true');p.add_argument('--out',type=Path,required=True);args=p.parse_args()
rows=[json.loads(s) for s in (ROOT/'evidence/confirmation_responses.jsonl').read_text().splitlines()]
assert len(rows)==576 and len({(r['model'],r['problem'],r['arm']) for r in rows})==576
source_hashes={r['sha256'] for r in json.loads((ROOT/'omitted_prompt_records.json').read_text())['records']}
for r in rows:
 assert r['source_record_sha256'] in source_hashes
 assert hashlib.sha256(r['response'].encode()).hexdigest()==r['response_utf8_sha256']
 impl=base.extract_impl(r['response']);wrapped=False
 if impl is None:
  t=r['response'].strip();fence=re.fullmatch(r'```(?:rust)?\s*(.*?)```',t,re.S|re.I)
  if fence:t=fence.group(1).strip()
  if re.match(r'^pub\s+fn\s+',t) and 'impl Solution' not in t:impl='impl Solution {\n'+t+'\n}';wrapped=True
 assert impl==r['impl'] and wrapped==r['tolerant_wrapped']
selected=[r for r in rows if 'gemma' in r['model'] and r['arm']=='nl' and r['tolerant_wrapped']]
assert len(selected)==36
out={'records_checked':len(rows),'extraction_mismatches':0,'wrapped_gemma_nl':len(selected),'execution_performed':args.execute}
if args.execute:
 assert args.benchmark and args.tests,'Provide --benchmark and --tests.'
 expected={r['problem']:r['sha256'] for r in json.loads((ROOT/'programming/manifests/r4b_testcase_manifest.json').read_text())['files']}
 fixtures=json.loads((ROOT/'evidence/wrapper_fixture_hashes.json').read_text())
 def run(r):
  pd=args.benchmark/r['family']/r['problem'];tc=args.tests/r['family']/r['problem']/'testcases.jsonl';h=pd/('tests/harness.rs' if r['family']=='leetcode' else 'main.rs')
  assert hashlib.sha256(tc.read_bytes()).hexdigest()==expected[r['problem']]
  assert hashlib.sha256(h.read_bytes()).hexdigest()==fixtures[r['problem']]['harness_sha256']
  ev=base.evaluate_impl(pd,r['family'],r['impl'],tc)
  return {'task':r['problem'],'compile_ok':ev['compile_ok'],'semantic_pass':ev['semantic_pass'],'matches_retained':ev['semantic_pass']==r['eval']['semantic_pass'] and ev['compile_ok']==r['eval']['compile_ok']}
 with ThreadPoolExecutor(max_workers=4) as pool:out['execution']=list(pool.map(run,selected))
 assert all(r['matches_retained'] for r in out['execution'])
 assert sum(r['compile_ok'] for r in out['execution'])==26 and sum(r['semantic_pass'] for r in out['execution'])==16
args.out.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='execution'},indent=2))
