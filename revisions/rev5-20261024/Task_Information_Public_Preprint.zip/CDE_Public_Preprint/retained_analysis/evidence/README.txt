Rev5 missing-evidence supplement, 24 October 2026

confirmation_responses.jsonl contains all 576 original generated responses and extracted implementations. Prompt text and the duplicated Ollama envelope are excluded. Response strings are unchanged. Original combined-record SHA256 and response-only SHA256 are separate: the original digest cannot be reconstructed from the reduced record. Personal temporary paths in evaluation errors are redacted.

From retained_analysis/:
  python3 evidence/verify_responses.py --out extraction_check.json

To rerun the 36 wrapped Gemma NL programs, obtain VeriContest at the revision in upstream_manifest.json and the positive tests identified by programming/manifests/r4b_testcase_manifest.json. Existing programming/analysis/r4b_fetch_tests.py documents fetching; see its --help. Run generated code only in a suitable sandbox:
  python3 evidence/verify_responses.py --execute --benchmark /path/to/vericontest/benchmark --tests /path/to/selected --out execution_check.json
Both testcase and harness hashes are checked before execution. Rust 1.98.1 was used in the verified run. Expected: 26 compiled, 16 passed, all 36 outcomes matched. No new model inference is performed.

Development sensitivity:
  python3 evidence/verify_development.py --repo . --out development_check.json
Requires numpy, pandas and scikit-learn (verified using 1.24.4, 1.5.3 and 1.6.1). The adapter retains the original programming fits and arithmetic but omits its unrelated ADeLe block and changes input paths to this archive. The unchanged original audit script is in development/post_review/. The adapter needs only included pilot outcomes, task features and r4b_analyze_pilot.py. Expected deduplicated losses (within floating-point rounding): 0.6489204115245689 and 0.6721778864477724; gate false.
The original full historical script additionally expects its old ADeLe dataset/layout and is retained for provenance, not advertised as the portable entry point.

Reference outputs are supplied. They establish reproduction on fixed data/tests; not correctness on every input, independent timing certification, or repeated-generation reliability.
