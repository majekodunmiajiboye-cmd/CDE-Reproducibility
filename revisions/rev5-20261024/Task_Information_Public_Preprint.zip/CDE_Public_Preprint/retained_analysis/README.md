# Retained analysis archive — Rev5

Supports the Rev5 manuscript dated 24 October 2026. Earlier source artifacts and outcomes are retained. New evidence is documented in `evidence/README.txt`: all 576 response-only records, extraction verification, a 36-program wrapper rerun entry point with fixture hashes, and portable developmental deduplication refitting.

The archive includes complete out-of-fold predictions for fixed, nested and extended-regularisation analyses; programming protocols and outcome metadata; original runners; and task manifests. `file_manifest.json` describes Rev5 exports. Original Rev4 manifest is retained as `file_manifest_rev4.json` for provenance only.

Model weights, embedding cache, benchmark prompt statements and upstream tests are not redistributed. Original combined prompt/response records remain omitted and hashed in `omitted_prompt_records.json`. Their generated response text is now supplied separately without prompts. Upstream revisions and licences are recorded in `upstream_manifest.json`. Paths in diagnostics are anonymised.

No new candidate generations were made. Post-hoc analyses remain post hoc. Study 1 scripts accept explicit upstream data paths; use --help. The historical confirmation runner uses its original relative import layout as described in its source; `evidence/verify_responses.py` is the portable no-inference extraction/execution entry point.

Use Python 3.11 with environment/requirements.txt. The original pins are not compatible with Python 3.13. The historical run_confirmation_v1.py runner is preserved as source provenance and does not run directly from this archive without restoring its original module layout and upstream inputs. Use evidence/verify_responses.py for portable verification from the included records.
