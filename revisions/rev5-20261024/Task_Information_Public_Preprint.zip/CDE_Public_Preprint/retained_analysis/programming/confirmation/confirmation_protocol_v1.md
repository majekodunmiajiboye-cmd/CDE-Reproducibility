# CDE reserved-set representation confirmation protocol v1

Status: prospective for the untouched 72-task confirmation set. Written after inspection and outcome-aware tolerant re-evaluation of the 24-task development pilot. It does not change the status of any pilot analysis.

## Data and models
Use exactly the 72 tasks in `manifests/r4b_task_manifest.json` under `confirm`. Before generation, verify that no confirmation-result files exist. Use the two retained local checkpoints from the development pilot: `devstral-small-2:24b-instruct-2512-q4_K_M` and `gemma3:12b`. One generation per model, task and arm. Temperature 0, seed 20260926, context 32768, maximum 4096 generated tokens. No repair round.

## Four arms
1. NL: natural-language description with the Starter Code section removed.
2. NL+scaffold: the same NL text plus a canonical scaffold copied in the same structural form exposed by the specification: `pub struct Solution;` followed by `impl Solution { <target stable-Rust signature> { } }`.
3. SPEC: the original formal Verus specification only.
4. BOTH: the same NL text plus the original formal Verus specification.

The common instruction and stable-Rust target signature are identical in all arms. SPEC and BOTH retain the original specification text unchanged. NL+scaffold contains no formal contracts or helper specification functions.

## Prospective evaluator
The evaluator is wrapper tolerant for all four arms and both models. First apply the original `impl Solution { ... }` extractor. If it fails and the response consists of a bare stable-Rust target function body beginning with `pub fn`, mechanically enclose the unchanged response in `impl Solution { ... }`. No tokens inside the model response may be edited. Other extraction failures remain failures. Compile and semantic-test using the same frozen harness and packaged positive tests as the development pilot.

Record separately: original extraction success, tolerant wrapping invoked, compile success, semantic success, and failure class.

## Primary estimands and tests
Within each model, two primary paired contrasts are fixed:
A. Scaffold effect: NL+scaffold minus NL semantic success.
B. Additional specification-content effect: BOTH minus NL+scaffold semantic success.

For each contrast report paired success rates, percentage-point difference, discordant counts b (control fail, treatment pass) and c (control pass, treatment fail), and the two-sided exact McNemar/binomial p-value conditional on b+c. Control family-wise type-I error within each model across the two primary contrasts using Bonferroni alpha = 0.025 per contrast. Report exact p-values regardless of threshold.

## Secondary analyses
SPEC minus NL+scaffold is secondary because it adds formal specification content while removing NL text. SPEC minus NL and BOTH minus NL are descriptive continuity contrasts with the development pilot. Between-model differences in arm effects are secondary and reported with task-level paired differences and exact sign tests. No secondary result can replace a failed primary contrast.

## Multiplicity and uncertainty
Primary inference is exact paired inference. Paired task bootstrap intervals may be reported as effect-size summaries but are secondary to exact tests. No selection of the largest observed contrast is used in confirmation.

## Failure and stopping rules
Run all 72 tasks in all four arms for both models unless a technical failure prevents evaluation. Do not stop for effect size or significance. A generation/API failure may be retried only to obtain a response under identical frozen settings and must be logged. Compilation, extraction and semantic failures are outcomes, not reasons for rerun. Any protocol or harness defect discovered after outcomes are visible is documented and corrected only in a separately labelled sensitivity unless it makes the intended evaluation impossible.

## Separation from development evidence
The wrapper-tolerant evaluator is outcome-aware and post hoc for the 24-task development pilot. It is prospective only for this 72-task confirmation because this protocol and its code hash are fixed before any confirmation generation.
