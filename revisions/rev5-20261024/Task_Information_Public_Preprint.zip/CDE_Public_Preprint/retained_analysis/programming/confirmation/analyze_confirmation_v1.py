from __future__ import annotations
import argparse,json,math,csv
from pathlib import Path

def exact(b:int,c:int)->float:
    n=b+c
    if n==0:return 1.0
    k=min(b,c)
    return min(1.0,2*sum(math.comb(n,i) for i in range(k+1))/(2**n))

def paired(rows,model,treat,control):
    by={(r['problem'],r['arm']):int(r['eval'].get('semantic_pass',False)) for r in rows if r['model']==model}
    probs=sorted({r['problem'] for r in rows if r['model']==model})
    if any((p,a) not in by for p in probs for a in [treat,control]): return None
    b=sum(by[p,control]==0 and by[p,treat]==1 for p in probs); c=sum(by[p,control]==1 and by[p,treat]==0 for p in probs)
    return {'treatment':treat,'control':control,'n':len(probs),'treatment_success':sum(by[p,treat] for p in probs),'control_success':sum(by[p,control] for p in probs),'gain_discordant_b':b,'loss_discordant_c':c,'effect_pp':100*(b-c)/len(probs),'exact_mcnemar_p_two_sided':exact(b,c)}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('result',type=Path);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();d=json.loads(args.result.read_text());rows=d['results']; models=d['models']; expected=len(models)*d['n_tasks']*len(d['arms']);
 if len(rows)!=expected: raise SystemExit(f'incomplete: {len(rows)}/{expected} cells')
 keys=[(r['model'],r['problem'],r['arm']) for r in rows]
 if len(set(keys))!=expected: raise SystemExit('duplicate cells')
 out={'protocol':d.get('protocol'),'seed':d.get('seed'),'n_tasks':d['n_tasks'],'n_cells':len(rows),'models':{},'primary_alpha_per_test':0.025}
 for m in models:
  out['models'][m]={'arm_counts':{a:sum(int(r['eval'].get('semantic_pass',False)) for r in rows if r['model']==m and r['arm']==a) for a in d['arms']},'extraction':{a:{'original':sum(bool(r['original_impl_extracted']) for r in rows if r['model']==m and r['arm']==a),'tolerant_wrapped':sum(bool(r['tolerant_wrapped']) for r in rows if r['model']==m and r['arm']==a),'accepted':sum(bool(r['accepted_impl']) for r in rows if r['model']==m and r['arm']==a)} for a in d['arms']}}
  out['models'][m]['primary']={'scaffold':paired(rows,m,'nl_scaffold','nl'),'spec_content':paired(rows,m,'both','nl_scaffold')}
  out['models'][m]['secondary']={'spec_vs_nl_scaffold':paired(rows,m,'spec','nl_scaffold'),'spec_vs_nl':paired(rows,m,'spec','nl'),'both_vs_nl':paired(rows,m,'both','nl')}
 args.out.write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
if __name__=='__main__':main()
