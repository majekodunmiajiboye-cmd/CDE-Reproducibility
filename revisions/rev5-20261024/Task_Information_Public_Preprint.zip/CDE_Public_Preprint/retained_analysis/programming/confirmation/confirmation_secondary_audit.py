#!/usr/bin/env python3
import json, math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'confirmation_result.json').read_text())['results']
models=['devstral-small-2:24b-instruct-2512-q4_K_M','gemma3:12b']
by={m:{(r['problem'],r['arm']):int(r['eval'].get('semantic_pass',False)) for r in D if r['model']==m} for m in models}
problems=sorted({r['problem'] for r in D})
def exact(a,b):
 n=a+b
 if not n:return 1.0
 k=min(a,b)
 return min(1.0,2*sum(math.comb(n,i) for i in range(k+1))/(2**n))
contrasts=[
 ('scaffold','nl_scaffold','nl','primary'),
 ('additional_spec','both','nl_scaffold','primary'),
 ('spec_vs_nl_scaffold','spec','nl_scaffold','secondary'),
 ('spec_vs_nl','spec','nl','secondary'),
 ('both_vs_nl','both','nl','secondary')]
out={'n_tasks':72,'within_model':{},'between_model_gemma_minus_devstral':{}}
for name,t,c,status in contrasts:
 out['within_model'][name]={'status':status}
 for m in models:
  vals=[by[m][p,t]-by[m][p,c] for p in problems]
  b=sum(v==1 for v in vals); cc=sum(v==-1 for v in vals)
  out['within_model'][name][m]={'effect_pp':100*sum(vals)/72,'gain_b':b,'loss_c':cc,'exact_mcnemar_p':exact(b,cc)}
 diffs=[(by[models[1]][p,t]-by[models[1]][p,c])-(by[models[0]][p,t]-by[models[0]][p,c]) for p in problems]
 pos=sum(v>0 for v in diffs); neg=sum(v<0 for v in diffs); zero=sum(v==0 for v in diffs)
 out['between_model_gemma_minus_devstral'][name]={'status':'secondary','effect_pp':100*sum(diffs)/72,'positive_task_differences':pos,'negative_task_differences':neg,'zero_task_differences':zero,'exact_sign_p':exact(pos,neg)}
(ROOT/'confirmation_secondary_audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
