#!/usr/bin/env python3
import json, math, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'confirmation_result.json').read_text()); A=json.loads((ROOT/'confirmation_analysis.json').read_text()); S=json.loads((ROOT/'confirmation_secondary_audit.json').read_text())
rows=D['results']; expected=len(D['models'])*D['n_tasks']*len(D['arms']); keys=[(r['model'],r['problem'],r['arm']) for r in rows]
assert len(rows)==expected==576 and len(set(keys))==576
assert sum(r.get('ollama',{}).get('done_reason')=='length' for r in rows)==2
# Frozen hashes
freeze_lines=[line.split() for line in (ROOT/'FREEZE.txt').read_text().splitlines() if line.strip()]
protocol_hash=next(parts[1] for parts in freeze_lines if parts[0]=='protocol_sha256')
runner_hash=next(parts[0] for parts in freeze_lines if parts[-1]=='run_confirmation_v1.py')
assert hashlib.sha256((ROOT/'confirmation_protocol_v1.md').read_bytes()).hexdigest()==protocol_hash
assert hashlib.sha256((ROOT/'run_confirmation_v1.py').read_bytes()).hexdigest()==runner_hash
# Primary counts and exact p values
def exact(b,c):
 n=b+c
 if n==0:return 1.0
 k=min(b,c);return min(1.0,2*sum(math.comb(n,i) for i in range(k+1))/(2**n))
expected_primary={
 'devstral-small-2:24b-instruct-2512-q4_K_M':{'scaffold':(7,5,2.7777777777777777),'spec_content':(14,9,6.944444444444445)},
 'gemma3:12b':{'scaffold':(3,2,1.3888888888888888),'spec_content':(9,2,9.722222222222221)}}
for m,cs in expected_primary.items():
 for k,(b,c,effect) in cs.items():
  x=A['models'][m]['primary'][k];assert (x['gain_discordant_b'],x['loss_discordant_c'])==(b,c);assert abs(x['effect_pp']-effect)<1e-12;assert abs(x['exact_mcnemar_p_two_sided']-exact(b,c))<1e-12
# Key compliance/success counts
assert A['models']['devstral-small-2:24b-instruct-2512-q4_K_M']['arm_counts']=={'nl':39,'nl_scaffold':41,'spec':34,'both':46}
assert A['models']['gemma3:12b']['arm_counts']=={'nl':28,'nl_scaffold':29,'spec':30,'both':36}
assert A['models']['gemma3:12b']['extraction']['nl']['original']==36
assert A['models']['gemma3:12b']['extraction']['nl']['tolerant_wrapped']==36
# Complete prespecified secondary set, added as a post-confirmation reporting audit without changing the frozen protocol.
assert S['within_model']['spec_vs_nl_scaffold']['devstral-small-2:24b-instruct-2512-q4_K_M']['gain_b']==11
assert S['within_model']['spec_vs_nl_scaffold']['devstral-small-2:24b-instruct-2512-q4_K_M']['loss_c']==18
assert S['within_model']['spec_vs_nl_scaffold']['gemma3:12b']['gain_b']==13
assert S['within_model']['spec_vs_nl_scaffold']['gemma3:12b']['loss_c']==12
assert S['within_model']['both_vs_nl']['devstral-small-2:24b-instruct-2512-q4_K_M']['gain_b']==15
assert S['within_model']['both_vs_nl']['devstral-small-2:24b-instruct-2512-q4_K_M']['loss_c']==8
assert S['within_model']['both_vs_nl']['gemma3:12b']['gain_b']==10
assert S['within_model']['both_vs_nl']['gemma3:12b']['loss_c']==2
assert abs(S['within_model']['both_vs_nl']['gemma3:12b']['exact_mcnemar_p']-0.03857421875)<1e-12
assert S['between_model_gemma_minus_devstral']['spec_vs_nl_scaffold']['positive_task_differences']==23
assert S['between_model_gemma_minus_devstral']['spec_vs_nl_scaffold']['negative_task_differences']==15
assert all(x['exact_sign_p']>=0.05 for x in S['between_model_gemma_minus_devstral'].values())
print('Confirmation artifacts verified: 576 unique cells, frozen hashes, primary exact tests, complete prespecified secondary contrasts, arm counts, and compliance counts.')
