from __future__ import annotations
import argparse,json,re,sys,time,urllib.request
from pathlib import Path
sys.path.insert(0,str(Path('supp/supplement/analysis').resolve()))
import r4b_local_pilot as base
SEED=20260926
ARMS=('nl','nl_scaffold','spec','both')
COMMON=base.COMMON

def scaffold(sig:str)->str:
    return 'pub struct Solution;\n\nimpl Solution {\n    '+sig+' {\n    }\n}\n'

def build_prompt(problem_dir:Path,arm:str):
    desc=(problem_dir/'description.md').read_text(errors='replace'); spec=(problem_dir/'spec.rs').read_text(errors='replace')
    fn=base.function_name_from_spec(spec); sig=base.starter_signature(desc,fn); nl=base.strip_starter(desc)
    pieces=[COMMON,f'\nTARGET SIGNATURE:\n{sig}\n']
    if arm in ('nl','nl_scaffold','both'): pieces.append('\nNATURAL-LANGUAGE TASK:\n'+nl+'\n')
    if arm=='nl_scaffold': pieces.append('\nOUTPUT SCAFFOLD:\n'+scaffold(sig))
    if arm in ('spec','both'): pieces.append('\nFORMAL VERUS SPECIFICATION:\n'+spec+'\n')
    pieces.append('\nReturn only the `impl Solution { ... }` block now.\n')
    return ''.join(pieces),sig

def tolerant_extract(text:str):
    impl=base.extract_impl(text)
    if impl is not None:return impl,False
    t=text.strip(); fence=re.fullmatch(r'```(?:rust)?\s*(.*?)```',t,re.S|re.I)
    if fence:t=fence.group(1).strip()
    if re.match(r'^pub\s+fn\s+',t) and 'impl Solution' not in t:
        return 'impl Solution {\n'+t+'\n}',True
    return None,False

def generate(model,prompt): return base.ollama_generate(model,prompt)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--selection',type=Path,required=True); ap.add_argument('--repo',type=Path,required=True); ap.add_argument('--test-root',type=Path,required=True); ap.add_argument('--out-dir',type=Path,required=True); ap.add_argument('--models',nargs='+',required=True); args=ap.parse_args()
    args.out_dir.mkdir(parents=True,exist_ok=True); tasks=json.loads(args.selection.read_text())['confirm']; results=[]
    result_file=args.out_dir/'confirmation_result.json'
    if result_file.exists():
        old=json.loads(result_file.read_text()); results=old.get('results',[])
    done={(x['model'],x['problem'],x['arm']) for x in results}
    for model in args.models:
      safe=model.replace(':','_').replace('/','_')
      for ti,item in enumerate(tasks,1):
        pdir=args.repo/item['family']/item['problem']; testcase=args.test_root/item['family']/item['problem']/'testcases.jsonl'
        for arm in ARMS:
          key=(model,item['problem'],arm)
          if key in done: continue
          prompt,sig=build_prompt(pdir,arm); raw=generate(model,prompt); text=raw.get('response',''); impl,wrapped=tolerant_extract(text)
          ev={'compile_ok':False,'semantic_pass':False,'error':'no accepted implementation'} if impl is None else base.evaluate_impl(pdir,item['family'],impl,testcase)
          rec={'model':model,'problem':item['problem'],'family':item['family'],'task_index':ti,'arm':arm,'target_signature':sig,'prompt_chars':len(prompt),'response_chars':len(text),'original_impl_extracted':base.extract_impl(text) is not None,'tolerant_wrapped':wrapped,'accepted_impl':impl is not None,'eval':ev,'ollama':{k:raw.get(k) for k in ['done_reason','eval_count','eval_duration','load_duration','prompt_eval_count','prompt_eval_duration','total_duration','wall_seconds_client']}}
          results.append(rec); done.add(key)
          result_file.write_text(json.dumps({'protocol':'confirmation_protocol_v1.md','seed':SEED,'arms':ARMS,'n_tasks':len(tasks),'models':args.models,'results':results},indent=2))
          od=args.out_dir/'raw'/safe/item['problem']; od.mkdir(parents=True,exist_ok=True); (od/(arm+'.json')).write_text(json.dumps({'prompt':prompt,'response':text,'impl':impl,'tolerant_wrapped':wrapped,'ollama':raw},indent=2))
          print(f'{model} {ti:02d}/{len(tasks)} {item["problem"]} {arm}: wrap={wrapped} compile={ev.get("compile_ok")} pass={ev.get("semantic_pass")}',flush=True)
if __name__=='__main__':main()
