from __future__ import annotations

import argparse
import hashlib
import json
import os
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from scipy.special import expit
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss
from sklearn.preprocessing import OneHotEncoder, StandardScaler


SEED = 20260926
EMBED_MODEL = "nomic-embed-text:latest"
EMBED_MODEL_ID = "0a109f422b47"
PREFIX = "classification: "
TEXT_DIMS = 18
DEMANDS = [
    "AS", "CEc", "CEe", "CL", "KNn", "KNa", "KNc", "KNf", "KNs",
    "MCt", "MCu", "MCr", "MS", "QLq", "QLl", "SNs", "VO", "AT",
]
META = ["instance_id", "benchmark", "task", "UG"]
OUTCOME = "verification_final"
SPECS = ["R", "RD", "RT18", "RT18D", "RTFULL", "RTFULLD"]


def clip_logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(np.asarray(p, dtype=float), 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def load_data(data_dir: Path, battery_file: Path):
    files = sorted(data_dir.glob("*.csv"))
    if len(files) != 15:
        raise RuntimeError(f"Expected 15 ADeLe subject files; found {len(files)}")
    base = pd.read_csv(battery_file, usecols=META + DEMANDS, low_memory=False)
    ys, names = [], []
    for f in files:
        d = pd.read_csv(f, usecols=["instance_id", OUTCOME], low_memory=False)
        d[OUTCOME] = pd.to_numeric(d[OUTCOME], errors="coerce")
        if not np.array_equal(d["instance_id"].astype(str).values, base["instance_id"].astype(str).values):
            raise RuntimeError(f"Instance ordering mismatch in {f.name}")
        ys.append(d[OUTCOME].to_numpy(dtype=float))
        names.append(f.stem)
    for c in ["UG"] + DEMANDS:
        base[c] = pd.to_numeric(base[c], errors="coerce")
    y = np.vstack(ys)
    keep = (
        np.isfinite(y).all(axis=0)
        & base[["UG"] + DEMANDS].notna().all(axis=1).to_numpy()
        & (base["UG"].to_numpy(dtype=float) >= 75.0)
    )
    base = base.loc[keep].reset_index(drop=True)
    y = y[:, keep]
    if not np.isin(y, [0.0, 1.0]).all():
        raise RuntimeError("Non-binary verification_final values after filtering")
    return base, y.astype(np.int8), names


def question_texts(base: pd.DataFrame, battery_file: Path) -> list[str]:
    raw = pd.read_csv(battery_file, usecols=["instance_id", "question"], low_memory=False)
    qmap = raw.set_index(raw.instance_id.astype(str))["question"]
    out = []
    for x in base.instance_id.astype(str):
        if x not in qmap.index:
            raise RuntimeError(f"Missing question for instance_id={x}")
        out.append(str(qmap.loc[x]))
    return out


def _cache_fingerprint(instance_ids: list[str], texts: list[str]) -> str:
    h = hashlib.sha256()
    h.update((EMBED_MODEL_ID + "\n" + PREFIX + "\n").encode())
    for i, t in zip(instance_ids, texts):
        h.update(i.encode()); h.update(b"\0"); h.update(t.encode()); h.update(b"\0")
    return h.hexdigest()


def embed_questions(instance_ids: list[str], texts: list[str], cache: Path, batch_size: int = 128) -> np.ndarray:
    fingerprint = _cache_fingerprint(instance_ids, texts)
    if cache.exists():
        z = np.load(cache, allow_pickle=False)
        arr = z["embeddings"]
        saved_fp = str(z["fingerprint"].item())
        if saved_fp != fingerprint:
            raise RuntimeError("Embedding cache fingerprint mismatch")
        if arr.shape != (len(texts), 768):
            raise RuntimeError(f"Embedding cache shape mismatch: {arr.shape}")
        return arr.astype(np.float32, copy=False)

    blocks = []
    prefixed = [PREFIX + t for t in texts]
    for start in range(0, len(prefixed), batch_size):
        batch = prefixed[start:start + batch_size]
        payload = {"model": EMBED_MODEL, "input": batch, "truncate": True, "keep_alive": "30m"}
        req = urllib.request.Request(
            "http://127.0.0.1:11434/api/embed",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=1800) as r:
            response = json.loads(r.read())
        block = np.asarray(response["embeddings"], dtype=np.float32)
        if block.shape != (len(batch), 768):
            raise RuntimeError(f"Unexpected embedding block shape {block.shape}")
        blocks.append(block)
        if start == 0 or ((start // batch_size + 1) % 10 == 0):
            print(f"embedded {min(start + batch_size, len(prefixed))}/{len(prefixed)}", flush=True)
    arr = np.vstack(blocks)
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(cache, embeddings=arr, fingerprint=np.asarray(fingerprint))
    return arr


def zfit(train: np.ndarray, test: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    s = StandardScaler()
    return s.fit_transform(train), s.transform(test)


def benchmark_blocks(train_bench: np.ndarray, test_bench: np.ndarray):
    enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float64)
    tr = enc.fit_transform(train_bench.reshape(-1, 1))
    te = enc.transform(test_bench.reshape(-1, 1))
    return tr, te, [str(x) for x in enc.categories_[0]]


def fit_prob(xtr: np.ndarray, ytr: np.ndarray, xte: np.ndarray, C: float = 1.0) -> np.ndarray:
    if np.unique(ytr).size < 2:
        return np.full(xte.shape[0], float(ytr.mean()))
    mdl = LogisticRegression(
        penalty="l2", C=C, solver="liblinear", max_iter=4000, random_state=SEED
    )
    mdl.fit(xtr, ytr)
    return mdl.predict_proba(xte)[:, list(mdl.classes_).index(1)]


def target_panel(y: np.ndarray, target_idx: int) -> np.ndarray:
    idx = [j for j in range(y.shape[0]) if j != target_idx]
    panel = y[idx].T.astype(np.float64)
    panel_p = (panel.sum(axis=1) + 0.5) / (len(idx) + 1.0)
    return np.column_stack([clip_logit(panel_p), panel])


def run_fold(
    fold_no: int,
    group: str,
    group_col: str,
    base: pd.DataFrame,
    y: np.ndarray,
    names: list[str],
    emb: np.ndarray,
    max_targets: int | None,
) -> tuple[list[dict], dict]:
    test_mask = base[group_col].astype(str).eq(group).to_numpy()
    tr_idx = np.flatnonzero(~test_mask)
    te_idx = np.flatnonzero(test_mask)
    if len(te_idx) == 0:
        return [], {}

    train_bench = base.iloc[tr_idx].benchmark.astype(str).to_numpy()
    test_bench = base.iloc[te_idx].benchmark.astype(str).to_numpy()
    btr, bte, categories = benchmark_blocks(train_bench, test_bench)

    unseen_benchmark_assertion = None
    if group_col == "benchmark":
        if group in set(train_bench):
            raise AssertionError(f"Held-out benchmark leaked into training: {group}")
        if group in categories:
            raise AssertionError(f"Held-out benchmark unexpectedly appears in encoder categories: {group}")
        if not np.allclose(bte, 0.0):
            raise AssertionError(f"Held-out benchmark did not map to all-zero one-hot block: {group}")
        unseen_benchmark_assertion = True

    d = base[DEMANDS].to_numpy(np.float64)
    dtr, dte = zfit(d[tr_idx], d[te_idx])

    pca = PCA(n_components=TEXT_DIMS, svd_solver="randomized", random_state=SEED)
    t18tr_raw = pca.fit_transform(emb[tr_idx])
    t18te_raw = pca.transform(emb[te_idx])
    t18tr, t18te = zfit(t18tr_raw, t18te_raw)
    tfulltr, tfullte = zfit(emb[tr_idx].astype(np.float64), emb[te_idx].astype(np.float64))

    rows: list[dict] = []
    n_targets = len(names) if max_targets is None else min(max_targets, len(names))
    for mi in range(n_targets):
        panel = target_panel(y, mi)
        ptr, pte = zfit(panel[tr_idx], panel[te_idx])
        blocks = {
            "R": (ptr, pte),
            "RD": (np.column_stack([ptr, dtr]), np.column_stack([pte, dte])),
            "RT18": (np.column_stack([ptr, t18tr]), np.column_stack([pte, t18te])),
            "RT18D": (np.column_stack([ptr, t18tr, dtr]), np.column_stack([pte, t18te, dte])),
            "RTFULL": (np.column_stack([ptr, tfulltr]), np.column_stack([pte, tfullte])),
            "RTFULLD": (np.column_stack([ptr, tfulltr, dtr]), np.column_stack([pte, tfullte, dte])),
        }
        pred = {}
        for spec, (ntr, nte) in blocks.items():
            xtr = np.column_stack([ntr, btr])
            xte = np.column_stack([nte, bte])
            pred[spec] = fit_prob(xtr, y[mi, tr_idx], xte, C=1.0)
        for pos, ii in enumerate(te_idx):
            row = {
                "model": names[mi],
                "instance_id": str(base.iloc[ii].instance_id),
                "benchmark": str(base.iloc[ii].benchmark),
                "task": str(base.iloc[ii].task),
                "heldout_group": group,
                "y": int(y[mi, ii]),
            }
            row.update({f"p_{spec}": float(pred[spec][pos]) for spec in SPECS})
            rows.append(row)
    meta = {
        "fold_no": fold_no,
        "heldout_group": group,
        "group_col": group_col,
        "n_train_items": int(len(tr_idx)),
        "n_test_items": int(len(te_idx)),
        "n_targets": n_targets,
        "benchmark_encoder_categories": categories,
        "unseen_benchmark_assertion": unseen_benchmark_assertion,
        "t18_explained_variance": float(pca.explained_variance_ratio_.sum()),
    }
    print(f"completed {group_col} fold {fold_no}: {group} ({len(te_idx)} items)", flush=True)
    return rows, meta


def losses(y: np.ndarray, p: np.ndarray) -> np.ndarray:
    p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
    yy = np.asarray(y, float)
    return -(yy * np.log(p) + (1 - yy) * np.log(1 - p))


def summarize(pred: pd.DataFrame, n_boot: int = 10000) -> dict:
    yy = pred.y.to_numpy(int)
    metrics = {}
    for spec in SPECS:
        p = np.clip(pred[f"p_{spec}"].to_numpy(float), 1e-6, 1 - 1e-6)
        metrics[spec] = {
            "log_loss": float(log_loss(yy, p, labels=[0, 1])),
            "brier": float(brier_score_loss(yy, p)),
            "accuracy_0p5_supplemental": float(np.mean((p >= 0.5) == yy)),
        }

    base_loss = losses(yy, pred.p_R.to_numpy(float))
    comparisons = {}
    rng = np.random.default_rng(SEED)
    benches = np.array(sorted(pred.benchmark.astype(str).unique()))
    bidx = {b: i for i, b in enumerate(benches)}
    for spec in SPECS:
        if spec == "R":
            continue
        diff = base_loss - losses(yy, pred[f"p_{spec}"].to_numpy(float))
        tmp = pd.DataFrame({"benchmark": pred.benchmark.astype(str), "diff": diff})
        sums = tmp.groupby("benchmark", sort=False)["diff"].sum()
        counts = tmp.groupby("benchmark", sort=False).size()
        sum_arr = np.array([float(sums.loc[b]) for b in benches])
        count_arr = np.array([float(counts.loc[b]) for b in benches])
        per_bench = {b: float(sums.loc[b] / counts.loc[b]) for b in benches}
        vals = np.empty(n_boot)
        for j in range(n_boot):
            ix = rng.integers(0, len(benches), len(benches))
            vals[j] = sum_arr[ix].sum() / count_arr[ix].sum()
        point = float(diff.mean())
        comparisons[spec] = {
            "contrast": f"R vs {spec}",
            "delta_ll_R_minus_spec": point,
            "relative_ll_reduction_vs_R": point / float(base_loss.mean()),
            "equal_benchmark_mean_delta": float(np.mean(list(per_bench.values()))),
            "benchmark_cluster_bootstrap_ci_2p5_50_97p5": [float(x) for x in np.quantile(vals, [0.025, 0.5, 0.975])],
            "n_boot": n_boot,
            "per_benchmark_delta": per_bench,
            "benchmark_sign_count_positive": int(sum(v > 0 for v in per_bench.values())),
            "benchmark_sign_count_zero": int(sum(v == 0 for v in per_bench.values())),
            "benchmark_sign_count_negative": int(sum(v < 0 for v in per_bench.values())),
        }
    return {"metrics": metrics, "comparisons_vs_R": comparisons}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--battery-file", type=Path, required=True)
    ap.add_argument("--embedding-cache", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--outer", choices=["lobo", "lotf"], required=True)
    ap.add_argument("--n-jobs", type=int, default=1)
    ap.add_argument("--max-folds", type=int)
    ap.add_argument("--max-targets", type=int)
    ap.add_argument("--n-boot", type=int, default=10000)
    args = ap.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    base, y, names = load_data(args.data_dir, args.battery_file)
    texts = question_texts(base, args.battery_file)
    emb = embed_questions(base.instance_id.astype(str).tolist(), texts, args.embedding_cache)
    if emb.shape != (len(base), 768):
        raise RuntimeError(f"Expected {(len(base), 768)} embeddings, got {emb.shape}")

    group_col = "benchmark" if args.outer == "lobo" else "task"
    groups = sorted(base[group_col].astype(str).unique())
    if args.max_folds is not None:
        groups = groups[: args.max_folds]

    jobs = [delayed(run_fold)(i + 1, g, group_col, base, y, names, emb, args.max_targets) for i, g in enumerate(groups)]
    outputs = Parallel(n_jobs=args.n_jobs, backend="loky", verbose=10)(jobs)
    rows = [row for rr, _ in outputs for row in rr]
    meta = [m for _, m in outputs if m]
    pred = pd.DataFrame(rows)
    if pred.empty:
        raise RuntimeError("No predictions generated")
    pred.to_csv(args.out_dir / f"{args.outer}_oof.csv.gz", index=False, compression="gzip")
    summary = summarize(pred, n_boot=args.n_boot)
    result = {
        "analysis": "Study 1: task characteristics beyond response profiles",
        "outer_validation": args.outer,
        "group_col": group_col,
        "seed": SEED,
        "n_models_total": len(names),
        "n_models_run": int(pred.model.nunique()),
        "n_items_total_after_filter": int(len(base)),
        "n_items_predicted": int(pred.instance_id.nunique()),
        "n_outer_groups_run": len(groups),
        "embedding": {
            "model": EMBED_MODEL,
            "expected_ollama_id": EMBED_MODEL_ID,
            "prefix": PREFIX,
            "dims": 768,
            "t18": "fold-local PCA to 18 dimensions, followed by fold-local standardization",
        },
        "predictors": SPECS,
        "primary_contrast": "R vs RTFULL under LOBO; all D cells descriptive existing-representation analyses",
        "estimator": "L2 logistic regression; C=1; liblinear; numerical standardization fit only on outer training rows; benchmark one-hot handle_unknown=ignore",
        "fold_metadata": meta,
        **summary,
    }
    (args.out_dir / f"{args.outer}_result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "outer": args.outer,
        "n_rows": len(pred),
        "metrics": result["metrics"],
        "comparisons_vs_R": {k: {kk: vv for kk, vv in v.items() if kk != "per_benchmark_delta"} for k, v in result["comparisons_vs_R"].items()},
    }, indent=2))


if __name__ == "__main__":
    main()
