# Study 1 extension — frozen analysis specification

Frozen before running the new analyses on 2026-09-27.

## Terminology and scientific target

Use **task characteristics**, not “task-side information”.

Primary question: **Does a generic representation of task characteristics improve response-conditioned prediction when the target benchmark is entirely absent from model fitting?**

This is benchmark-held-out response-conditioned transfer, not cold-start prediction: the response baseline retains the other 14 models' responses on each held-out item.

## Data and fixed provenance

- ADeLe upstream commit: `a93722320b5c46a371ef94c60c4333def37bbd57`
- Canonical battery SHA256 expected: `b978cdf1538d5c07e01bfb4a2636293641ac9a404b3385fdb1936fe6aec5b056`
- Analysis filter and 15 response files: identical to the archived paper pipeline.
- Seed: `20260926`.
- Text source: canonical ADeLe `question` field only.
- Embedding model: local `nomic-embed-text:latest`, expected Ollama ID `0a109f422b47`, 768 dimensions.
- New embedding input: `classification: ` + question text.
- The existing prefix-free T18 result is frozen historical evidence and is not replaced.

## Outer validation

Run both:

1. **LOBO**: 20 leave-one-benchmark-out folds. This is the primary new validation setting.
2. **LOTF**: the existing 63 leave-one-task-family-out folds, rerun with the new prefixed embeddings so within-benchmark-family and benchmark-held-out effects can be compared directly.

For every LOBO fold, assert that no held-out benchmark row enters training and that `OneHotEncoder(handle_unknown='ignore')` maps the held-out benchmark to an all-zero benchmark block.

## Predictors

All predictors use the same response-conditioned baseline R: Jeffreys-smoothed peer easiness, all 14 other-model binary item responses, and benchmark identity.

Run six cells in each outer-validation setting:

- `R`
- `R+D`
- `R+T18p`
- `R+T18p+D`
- `R+Tfull`
- `R+Tfull+D`

`D` is the published 18-coordinate ADeLe annotation system. It is reported as an existing interpretable representation, not as validation of CDE or a uniquely correct taxonomy.

`T18p` is 18 PCA components of the **prefixed** 768-d Nomic embeddings; PCA is fit only on outer-training items and held-out items are transform-only.

`Tfull` is the full 768-d prefixed Nomic embedding, with no PCA.

## Estimator

Primary estimator is frozen to match the paper:

- StandardScaler fit on outer-training rows only for numerical features.
- OneHotEncoder(handle_unknown='ignore') for benchmark identity.
- L2 logistic regression, `C=1`, `solver='liblinear'`, `max_iter=4000`, seed `20260926`.
- Target model is fitted separately; its own outcome never enters peer-response features.

## Primary contrast and interpretation

**Primary contrast:** `R` versus `R+Tfull` under LOBO.

This alone determines the new claim about transfer of task-characteristic information. All D-containing cells are descriptive/existing-representation analyses under the same conditions; they are not used to claim that the 18 ADeLe dimensions are special or that CDE is validated.

No arbitrary effect-size success threshold is introduced. Report the effect continuously.

## Outcomes

Primary outcome: binary log loss.

Report for every predictor/contrast:

- pooled log loss and pooled delta versus R;
- relative log-loss reduction versus R;
- equal-benchmark mean delta versus R;
- benchmark-cluster bootstrap 95% percentile interval using 10,000 draws;
- all 20 benchmark-specific deltas and sign count for LOBO;
- Brier score as a secondary probabilistic outcome.

Accuracy at threshold 0.5 is supplemental only, not a primary interpretation target.

## Regularisation sensitivity

After the fixed-C primary run, perform a sensitivity with C selected strictly inside each outer-training set from the predetermined grid `[0.01, 0.1, 1.0, 10.0]`, using identical selection logic for every representation. This sensitivity cannot replace the fixed-C result and is interpreted only as a check that representation dimensionality is not being driven by the frozen C=1 choice.

## Stop rule

No additional representations, taxonomies, benchmarks, post-hoc thresholds, or interaction models are added in response to the results of this run.
