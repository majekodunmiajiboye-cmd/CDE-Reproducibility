from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.decomposition import PCA
from sklearn.model_selection import GroupKFold

import study1_task_characteristics as s


C_GRID = (0.0001, 0.001, 0.01, 0.1, 1.0, 10.0)


def static_blocks(
    tr_idx: np.ndarray,
    te_idx: np.ndarray,
    base: pd.DataFrame,
    emb: np.ndarray,
) -> dict:
    train_bench = base.iloc[tr_idx].benchmark.astype(str).to_numpy()
    test_bench = base.iloc[te_idx].benchmark.astype(str).to_numpy()
    btr, bte, categories = s.benchmark_blocks(train_bench, test_bench)

    d = base[s.DEMANDS].to_numpy(np.float64)
    dtr, dte = s.zfit(d[tr_idx], d[te_idx])

    pca = PCA(n_components=s.TEXT_DIMS, svd_solver="randomized", random_state=s.SEED)
    t18tr_raw = pca.fit_transform(emb[tr_idx])
    t18te_raw = pca.transform(emb[te_idx])
    t18tr, t18te = s.zfit(t18tr_raw, t18te_raw)
    tfulltr, tfullte = s.zfit(emb[tr_idx].astype(np.float64), emb[te_idx].astype(np.float64))

    return {
        "btr": btr,
        "bte": bte,
        "dtr": dtr,
        "dte": dte,
        "t18tr": t18tr,
        "t18te": t18te,
        "tfulltr": tfulltr,
        "tfullte": tfullte,
        "categories": categories,
        "t18_explained_variance": float(pca.explained_variance_ratio_.sum()),
    }


def assemble(panel_tr: np.ndarray, panel_te: np.ndarray, z: dict) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    return {
        "R": (
            np.column_stack([panel_tr, z["btr"]]),
            np.column_stack([panel_te, z["bte"]]),
        ),
        "RD": (
            np.column_stack([panel_tr, z["dtr"], z["btr"]]),
            np.column_stack([panel_te, z["dte"], z["bte"]]),
        ),
        "RT18": (
            np.column_stack([panel_tr, z["t18tr"], z["btr"]]),
            np.column_stack([panel_te, z["t18te"], z["bte"]]),
        ),
        "RT18D": (
            np.column_stack([panel_tr, z["t18tr"], z["dtr"], z["btr"]]),
            np.column_stack([panel_te, z["t18te"], z["dte"], z["bte"]]),
        ),
        "RTFULL": (
            np.column_stack([panel_tr, z["tfulltr"], z["btr"]]),
            np.column_stack([panel_te, z["tfullte"], z["bte"]]),
        ),
        "RTFULLD": (
            np.column_stack([panel_tr, z["tfulltr"], z["dtr"], z["btr"]]),
            np.column_stack([panel_te, z["tfullte"], z["dte"], z["bte"]]),
        ),
    }


def select_c(
    mi: int,
    panel: np.ndarray,
    y: np.ndarray,
    inner: list[tuple[np.ndarray, np.ndarray, dict]],
) -> tuple[dict[str, float], dict[str, dict[str, float]]]:
    loss_sum = {spec: {c: 0.0 for c in C_GRID} for spec in s.SPECS}
    n_sum = {spec: {c: 0 for c in C_GRID} for spec in s.SPECS}

    for itr_idx, iva_idx, z in inner:
        ptr, pva = s.zfit(panel[itr_idx], panel[iva_idx])
        blocks = assemble(ptr, pva, z)
        ytr = y[mi, itr_idx]
        yva = y[mi, iva_idx]
        for spec, (xtr, xva) in blocks.items():
            for c in C_GRID:
                p = s.fit_prob(xtr, ytr, xva, C=c)
                loss_sum[spec][c] += float(s.losses(yva, p).sum())
                n_sum[spec][c] += int(len(yva))

    mean_loss = {
        spec: {str(c): loss_sum[spec][c] / n_sum[spec][c] for c in C_GRID}
        for spec in s.SPECS
    }
    selected = {}
    for spec in s.SPECS:
        # C_GRID is ordered low-to-high, so ties deterministically prefer the
        # stronger regularisation (smaller C).
        selected[spec] = min(C_GRID, key=lambda c: (mean_loss[spec][str(c)], c))
    return selected, mean_loss


def run_fold(
    fold_no: int,
    group: str,
    group_col: str,
    base: pd.DataFrame,
    y: np.ndarray,
    names: list[str],
    emb: np.ndarray,
    inner_folds: int,
    max_targets: int | None,
) -> tuple[list[dict], dict]:
    test_mask = base[group_col].astype(str).eq(group).to_numpy()
    tr_idx = np.flatnonzero(~test_mask)
    te_idx = np.flatnonzero(test_mask)
    if len(te_idx) == 0:
        return [], {}

    outer_z = static_blocks(tr_idx, te_idx, base, emb)
    if group_col == "benchmark":
        train_bench = set(base.iloc[tr_idx].benchmark.astype(str))
        if group in train_bench:
            raise AssertionError(f"Held-out benchmark leaked into outer training: {group}")
        if group in outer_z["categories"]:
            raise AssertionError(f"Held-out benchmark appeared in encoder categories: {group}")
        if not np.allclose(outer_z["bte"], 0.0):
            raise AssertionError(f"Held-out benchmark did not map to zero one-hot block: {group}")

    outer_groups = base.iloc[tr_idx][group_col].astype(str).to_numpy()
    n_unique = int(pd.Series(outer_groups).nunique())
    n_inner = min(inner_folds, n_unique)
    if n_inner < 2:
        raise RuntimeError("Need at least two inner groups for nested C selection")
    cv = GroupKFold(n_splits=n_inner)
    inner = []
    for inner_train_local, inner_val_local in cv.split(tr_idx, groups=outer_groups):
        itr_idx = tr_idx[inner_train_local]
        iva_idx = tr_idx[inner_val_local]
        if set(base.iloc[itr_idx][group_col].astype(str)) & set(base.iloc[iva_idx][group_col].astype(str)):
            raise AssertionError("Inner group leakage")
        inner.append((itr_idx, iva_idx, static_blocks(itr_idx, iva_idx, base, emb)))

    rows: list[dict] = []
    selected_by_model: dict[str, dict[str, float]] = {}
    inner_losses_by_model: dict[str, dict[str, dict[str, float]]] = {}
    n_targets = len(names) if max_targets is None else min(max_targets, len(names))
    for mi in range(n_targets):
        panel = s.target_panel(y, mi)
        selected, inner_losses = select_c(mi, panel, y, inner)
        selected_by_model[names[mi]] = selected
        inner_losses_by_model[names[mi]] = inner_losses

        ptr, pte = s.zfit(panel[tr_idx], panel[te_idx])
        blocks = assemble(ptr, pte, outer_z)
        pred = {
            spec: s.fit_prob(xtr, y[mi, tr_idx], xte, C=selected[spec])
            for spec, (xtr, xte) in blocks.items()
        }
        for pos, ii in enumerate(te_idx):
            row = {
                "model": names[mi],
                "instance_id": str(base.iloc[ii].instance_id),
                "benchmark": str(base.iloc[ii].benchmark),
                "task": str(base.iloc[ii].task),
                "heldout_group": group,
                "y": int(y[mi, ii]),
            }
            row.update({f"p_{spec}": float(pred[spec][pos]) for spec in s.SPECS})
            row.update({f"C_{spec}": float(selected[spec]) for spec in s.SPECS})
            rows.append(row)

    meta = {
        "fold_no": fold_no,
        "heldout_group": group,
        "group_col": group_col,
        "n_train_items": int(len(tr_idx)),
        "n_test_items": int(len(te_idx)),
        "n_targets": n_targets,
        "inner_groupkfold_splits": n_inner,
        "benchmark_encoder_categories": outer_z["categories"],
        "unseen_benchmark_assertion": True if group_col == "benchmark" else None,
        "t18_explained_variance": outer_z["t18_explained_variance"],
        "selected_c_by_model": selected_by_model,
        "inner_log_loss_by_model_spec_c": inner_losses_by_model,
    }
    print(f"completed nested-C {group_col} fold {fold_no}: {group} ({len(te_idx)} items)", flush=True)
    return rows, meta


def selected_c_summary(meta: list[dict]) -> dict:
    out = {spec: {str(c): 0 for c in C_GRID} for spec in s.SPECS}
    for fold in meta:
        for _, by_spec in fold["selected_c_by_model"].items():
            for spec, c in by_spec.items():
                out[spec][str(float(c))] += 1
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--battery-file", type=Path, required=True)
    ap.add_argument("--embedding-cache", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--outer", choices=["lobo", "lotf"], required=True)
    ap.add_argument("--inner-folds", type=int, default=3)
    ap.add_argument("--n-jobs", type=int, default=1)
    ap.add_argument("--max-folds", type=int)
    ap.add_argument("--max-targets", type=int)
    ap.add_argument("--n-boot", type=int, default=10000)
    args = ap.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    base, y, names = s.load_data(args.data_dir, args.battery_file)
    texts = s.question_texts(base, args.battery_file)
    emb = s.embed_questions(base.instance_id.astype(str).tolist(), texts, args.embedding_cache)
    if emb.shape != (len(base), 768):
        raise RuntimeError(f"Expected {(len(base), 768)} embeddings, got {emb.shape}")

    group_col = "benchmark" if args.outer == "lobo" else "task"
    groups = sorted(base[group_col].astype(str).unique())
    if args.max_folds is not None:
        groups = groups[: args.max_folds]

    outputs = Parallel(n_jobs=args.n_jobs, backend="loky", verbose=10)(
        delayed(run_fold)(i + 1, g, group_col, base, y, names, emb, args.inner_folds, args.max_targets)
        for i, g in enumerate(groups)
    )
    rows = [row for rr, _ in outputs for row in rr]
    meta = [m for _, m in outputs if m]
    pred = pd.DataFrame(rows)
    if pred.empty:
        raise RuntimeError("No predictions generated")
    pred.to_csv(args.out_dir / f"{args.outer}_nestedC_oof.csv.gz", index=False, compression="gzip")
    summary = s.summarize(pred, n_boot=args.n_boot)
    result = {
        "analysis": "Study 1 post-hoc extended-grid regularisation sensitivity: task characteristics beyond response profiles",
        "outer_validation": args.outer,
        "group_col": group_col,
        "seed": s.SEED,
        "n_models_total": len(names),
        "n_models_run": int(pred.model.nunique()),
        "n_items_total_after_filter": int(len(base)),
        "n_items_predicted": int(pred.instance_id.nunique()),
        "n_outer_groups_run": len(groups),
        "c_grid": list(C_GRID),
        "c_selection": f"{args.inner_folds}-fold GroupKFold inside each outer-training set; group={group_col}; pooled inner log loss; all preprocessing refit inside each inner split; C selected separately for each target model and representation",
        "selected_c_counts": selected_c_summary(meta),
        "embedding": {
            "model": s.EMBED_MODEL,
            "expected_ollama_id": s.EMBED_MODEL_ID,
            "prefix": s.PREFIX,
            "dims": 768,
            "t18": "fold-local PCA to 18 dimensions, followed by fold-local standardization",
        },
        "predictors": s.SPECS,
        "primary_contrast": "R vs RTFULL under LOBO; post-hoc extended-grid sensitivity only",
        "estimator": "L2 logistic regression; liblinear; C selected from [0.0001, 0.001, 0.01, 0.1, 1, 10] strictly within each outer-training set; numerical preprocessing and benchmark encoding nested within inner split",
        "fold_metadata": meta,
        **summary,
    }
    (args.out_dir / f"{args.outer}_nestedC_result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "outer": args.outer,
        "n_rows": len(pred),
        "selected_c_counts": result["selected_c_counts"],
        "metrics": result["metrics"],
        "comparisons_vs_R": {
            k: {kk: vv for kk, vv in v.items() if kk != "per_benchmark_delta"}
            for k, v in result["comparisons_vs_R"].items()
        },
    }, indent=2))


if __name__ == "__main__":
    main()
