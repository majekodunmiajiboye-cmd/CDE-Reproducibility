# Study 1 nested-C sensitivity implementation note

This note fixes the implementation of the regularisation sensitivity required by
`STUDY1_FREEZE.md` before the sensitivity is run.

The frozen specification fixed the C grid (`0.01, 0.1, 1.0, 10.0`) and required
selection strictly inside each outer-training set, but it did not specify the
inner resampling scheme. The fixed-C outcomes were already available when this
implementation detail was resolved, so the inner scheme below is transparently
post-freeze rather than described as preregistered.

For the primary LOBO sensitivity:

- C is selected separately for every outer fold, target model, and representation.
- Inner selection uses deterministic 3-fold `GroupKFold` on benchmark identity.
- No row from the outer held-out benchmark enters C selection.
- Within every inner split, benchmark encoding, numerical scaling, the 18-D PCA,
  and full-embedding scaling are refit on inner-training rows only.
- All six representations use exactly the same inner splits and C grid.
- C minimizes pooled inner-validation binary log loss; an exact tie selects the
  smaller C.
- The selected C is then refit on the complete outer-training set and evaluated
  once on the untouched outer benchmark.
- The fixed-C result remains primary. This run is only the prespecified
  dimensionality/regularisation sensitivity.

The secondary LOTF fixed-C analysis is already complete. The frozen sensitivity
language follows the fixed-C **primary** run and does not require LOTF nested-C;
LOBO is therefore the completion target for this sensitivity.
