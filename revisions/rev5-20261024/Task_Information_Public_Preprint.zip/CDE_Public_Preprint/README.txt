PUBLIC PREPRINT AND REPRODUCIBILITY PACKAGE — 24 October 2026

Separating task information from evaluation effects in language-model performance
Author: Majekodunmi Ajiboye
ORCID: https://orcid.org/0009-0000-5812-3925
Version DOI: https://doi.org/10.5281/zenodo.23619633
All versions: https://doi.org/10.5281/zenodo.22984124

manuscript/main.pdf is the named public preprint; manuscript/supplement.pdf is its supplement. Editable sources and numerical verification are in manuscript/. Retained outputs and response evidence are in retained_analysis/. See retained_analysis/evidence/README.txt for reproduction commands.

This version follows the September CDE reproducibility bundle, whose working-paper title was "Task content survives strong controls; taxonomy-specific and structured environment-transform claims do not". Its archive remains separately identifiable by DOI 10.5281/zenodo.22984125.

Use Python 3.11 for the retained-analysis environment/requirements.txt pins. These historical pins are not compatible with Python 3.13. The small manuscript audit has separate requirements in manuscript/analysis/requirements-audit.txt.

Verify file integrity with: shasum -a 256 -c SHA256SUMS
See RIGHTS.txt for material-specific licences. Original benchmark prompts and tests are not redistributed.
